let cart = [];

function addToCart(productName, sizeId, breadId) {
  const size = document.getElementById(sizeId).value;
  const bread = document.getElementById(breadId).value;

  let price = 0;
  if (size === "single") {
    price = productName === "CHAMA Clássico" ? 25 : 29;
  } else {
    price = productName === "CHAMA Clássico" ? 33 : 37;
  }

  // Adicionar ao carrinho
  cart.push({
    productName: productName,
    size: size === "single" ? "Simples" : "Duplo",
    bread: bread === "brioche" ? "Brioche" : "Parmesão",
    price: price
  });

  displayCart();
}

function displayCart() {
  const cartElement = document.getElementById("cart");
  cartElement.innerHTML = ""; // Limpa o carrinho antes de atualizar

  let total = 0;
  cart.forEach((item, index) => {
    cartElement.innerHTML += `<p>${item.productName} (${item.size}) - Pão: ${
      item.bread
    } - R$${item.price.toFixed(
      2
    )} <button onclick="removeFromCart(${index})">Remover</button></p>`;
    total += item.price;
  });

  // Adiciona taxa de entrega
  total += 5.0;

  cartElement.innerHTML += `<h3>Total com entrega: R$${total.toFixed(2)}</h3>`;
}

function removeFromCart(index) {
  cart.splice(index, 1);
  displayCart();
}

function finalizeOrder() {
  if (cart.length === 0) {
    alert("Seu carrinho está vazio!");
    return;
  }

  alert(
    "Pedido finalizado com sucesso! Total a pagar: R$" +
      (cart.reduce((acc, item) => acc + item.price, 0) + 5).toFixed(2)
  );

  // Limpar o carrinho após o pedido
  cart = [];
  displayCart();
}
